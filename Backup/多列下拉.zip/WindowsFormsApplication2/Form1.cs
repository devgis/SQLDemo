﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using LWQ.MyControl;
using System.Data.Common;

namespace WindowsFormsApplication2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            iniComboboxDW();

            iniDataGridViewDW();
        }

        /// <summary>
        /// 初始化combobox
        /// </summary>
        private void iniComboboxDW()
        {
            dataWindow1.sDisplayField = "学号,姓名,性别,专业,入学年份";
            dataWindow1.sDisplayMember = "姓名";
            dataWindow1.sKeyWords = "学号";
            dataWindow1.DataSource = createStudentTable();
            dataWindow1.RowFilterVisible = true;
            dataWindow1.AfterSelector += new AfterSelectorEventHandler(dataWindow1_AfterSelector);
        }

        /// <summary>
        /// 初始化DataGridView
        /// </summary>
        private void iniDataGridViewDW()
        {
            DataGridViewColumn column = new DataGridViewDataWindowColumn();

            (column as DataGridViewDataWindowColumn).SDisplayField = "学号,姓名,性别,专业,入学年份";
            (column as DataGridViewDataWindowColumn).SDisplayMember = "学号";
            (column as DataGridViewDataWindowColumn).SKeyWords = "学号";
            (column as DataGridViewDataWindowColumn).DataSource = createStudentTable();
            dataGridView1.Columns.Add(column);

            dataGridView1.Columns.Add(new DataGridViewTextBoxColumn());
            dataGridView1.Columns.Add(new DataGridViewTextBoxColumn());
            dataGridView1.Columns.Add(new DataGridViewTextBoxColumn());
            dataGridView1.Columns.Add(new DataGridViewTextBoxColumn());
        }

        /// <summary>
        /// 生产测试数据
        /// </summary>
        /// <returns></returns>
        private DataTable createStudentTable()
        {
            DataTable dt = new DataTable();
            DataColumn dc = new DataColumn("学号");
            dt.Columns.Add(dc);
            dc = new DataColumn("姓名");
            dt.Columns.Add(dc);
            dc = new DataColumn("性别");
            dt.Columns.Add(dc);
            dc = new DataColumn("专业");
            dt.Columns.Add(dc);
            dc = new DataColumn("入学年份");
            dt.Columns.Add(dc);

            DataRow dr = dt.NewRow();
            dr["学号"] = "20010101";
            dr["姓名"] = "刘德华";
            dr["性别"] = "男";
            dr["专业"] = "影视表演";
            dr["入学年份"] = "2001";
            dt.Rows.Add(dr);

            dr = dt.NewRow();
            dr["学号"] = "20010702";
            dr["姓名"] = "张学友";
            dr["性别"] = "男";
            dr["专业"] = "计算机科学技术";
            dr["入学年份"] = "2001";
            dt.Rows.Add(dr);

            dr = dt.NewRow();
            dr["学号"] = "20010403";
            dr["姓名"] = "郭富城";
            dr["性别"] = "男";
            dr["专业"] = "哲学系";
            dr["入学年份"] = "2001";
            dt.Rows.Add(dr);

            dr = dt.NewRow();
            dr["学号"] = "20010204";
            dr["姓名"] = "柳岩";
            dr["性别"] = "女";
            dr["专业"] = "模特专业（裸模方向）";
            dr["入学年份"] = "2001";
            dt.Rows.Add(dr);

            dr = dt.NewRow();
            dr["学号"] = "20010305";
            dr["姓名"] = "郭德纲";
            dr["性别"] = "男";
            dr["专业"] = "中文系";
            dr["入学年份"] = "2001";
            dt.Rows.Add(dr);

            return dt;
        }

        /// <summary>
        /// DataWindow选择后事件处理（获取在下拉框中选择的数据）
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        void dataWindow1_AfterSelector(object sender, AfterSelectorEventArgs e)
        {
            DataGridViewRow row = e.Value as DataGridViewRow;
            DataRowView dataRow = row.DataBoundItem as DataRowView;

            label1.Text = dataRow["学号"].ToString().Trim();
            label2.Text = dataRow["姓名"].ToString().Trim();
            label3.Text = dataRow["性别"].ToString().Trim();
            label4.Text = dataRow["专业"].ToString().Trim();
            label5.Text = dataRow["入学年份"].ToString().Trim();
        }

        /// <summary>
        /// 订阅DataGridView中的DataWindow选择事件
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void dataGridView1_EditingControlShowing(object sender, DataGridViewEditingControlShowingEventArgs e)
        {
            //e.CellStyle.BackColor = Color.FromName("window");

            
            if (e.Control is DataWindow)
            {
                (e.Control as DataWindow).AfterSelector -= new AfterSelectorEventHandler(SalePageAddOrEditForm_AfterSelector);
                (e.Control as DataWindow).AfterSelector += new AfterSelectorEventHandler(SalePageAddOrEditForm_AfterSelector);
            }
        }

        /// <summary>
        /// DataGridView中DataWindow选择后事件处理（获取在下拉框中选择的数据）
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        void SalePageAddOrEditForm_AfterSelector(object sender, AfterSelectorEventArgs e)
        {
            DataGridViewRow row = e.Value as DataGridViewRow;
            DataRowView dataRow = row.DataBoundItem as DataRowView;
            dataGridView1.Rows[e.RowIndex].Cells[1].Value = dataRow["姓名"].ToString().Trim();
            dataGridView1.Rows[e.RowIndex].Cells[2].Value = dataRow["性别"].ToString().Trim();
            dataGridView1.Rows[e.RowIndex].Cells[3].Value = dataRow["专业"].ToString().Trim();
            dataGridView1.Rows[e.RowIndex].Cells[4].Value = dataRow["入学年份"].ToString().Trim();
          
        }

    }
}
